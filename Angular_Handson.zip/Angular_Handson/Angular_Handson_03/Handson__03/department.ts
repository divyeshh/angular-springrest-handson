export interface Department{
    deptId:number;
    deptName:String;
}
